#!/bin/sh

# Change the following address to your GRIN addr.
ADDRESS=bminergrin
USERNAME=littledik.littledik
POOL=eu.frostypool.com:3516
SCHEME=cuckatoo31
PWD=foo

./bminer -uri $SCHEME://$USERNAME:$PWD@$POOL -api 127.0.0.1:1880
